import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gmaild',
  templateUrl: './gmaild.component.html',
  styleUrls: ['./gmaild.component.css']
})
export class GmaildComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
