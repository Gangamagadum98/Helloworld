import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-composed',
  templateUrl: './composed.component.html',
  styleUrls: ['./composed.component.css']
})
export class ComposedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
