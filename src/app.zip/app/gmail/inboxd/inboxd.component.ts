import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inboxd',
  templateUrl: './inboxd.component.html',
  styleUrls: ['./inboxd.component.css']
})
export class InboxdComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
