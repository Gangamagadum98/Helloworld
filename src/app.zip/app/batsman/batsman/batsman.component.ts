import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-batsman',
  templateUrl: './batsman.component.html',
  styleUrls: ['./batsman.component.css']
})
export class BatsmanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
