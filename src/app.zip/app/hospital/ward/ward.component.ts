import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ward',
  templateUrl: './ward.component.html',
  styleUrls: ['./ward.component.css']
})
export class WardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
