import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hosp',
  templateUrl: './hosp.component.html',
  styleUrls: ['./hosp.component.css']
})
export class HospComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
