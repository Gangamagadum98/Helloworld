import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-installerdetails',
  templateUrl: './installerdetails.component.html',
  styleUrls: ['./installerdetails.component.css']
})
export class InstallerdetailsComponent implements OnInit {
  

  constructor() { 
    
  }

  ngOnInit() {
    

  }

}
