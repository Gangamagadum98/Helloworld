import { PartyDirective } from './party.directive';

describe('PartyDirective', () => {
  it('should create an instance', () => {
    const directive = new PartyDirective();
    expect(directive).toBeTruthy();
  });
});
