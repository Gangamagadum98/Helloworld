import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bowler',
  templateUrl: './bowler.component.html',
  styleUrls: ['./bowler.component.css']
})
export class BowlerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
